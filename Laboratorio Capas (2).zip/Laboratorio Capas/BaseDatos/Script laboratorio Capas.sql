-- script de creacion de base de datos
CREATE DATABASE IF NOT EXISTS db_sistema_login;
USE db_sistema_login;

DROP TABLE IF EXISTS usuarios;
CREATE TABLE usuarios (
    id                    INT NOT NULL AUTO_INCREMENT,
    dsId                  VARCHAR(10) NOT NULL DEFAULT '',
    dsUsuario             VARCHAR(50) NOT NULL,
    dsPassword            VARBINARY(64) NOT NULL,
    dsEstado              CHAR(1) NOT NULL DEFAULT '1',
    dsUsuarioCreacion     VARCHAR(50) NOT NULL,
    dtFechaCreacion       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    idUsuarioModificacion VARCHAR(50) NULL,
    dtFechaModificacion   DATETIME NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_dsUsuario (dsUsuario)
);

-- usuario de prueba: admin / 123456 (SHA-512 guardado como bytes)
INSERT INTO usuarios (dsId, dsUsuario, dsPassword, dsEstado, dsUsuarioCreacion)
VALUES ('001', 'admin', UNHEX(SHA2('123456', 512)), '1', 'Sistema');


-- procedimiento almacenado sp_ObtenerUsuario
DROP PROCEDURE IF EXISTS sp_ObtenerUsuario;

DELIMITER $$
CREATE PROCEDURE sp_ObtenerUsuario(IN _dsUsuario VARCHAR(50))
BEGIN
    SELECT id, dsUsuario, HEX(dsPassword) AS dsPassword
    FROM usuarios
    WHERE dsUsuario = _dsUsuario
      AND dsEstado = '1';
END$$
DELIMITER ;


-- procedimiento almacenado sp_RegistrarUsuario
DROP PROCEDURE IF EXISTS sp_RegistrarUsuario;

DELIMITER $$
CREATE PROCEDURE sp_RegistrarUsuario(
    IN _dsUsuario         VARCHAR(50),
    IN _dsPassword        VARCHAR(128),
    IN _dsUsuarioCreacion VARCHAR(50)
)
BEGIN
    INSERT INTO usuarios (dsUsuario, dsPassword, dsEstado, dsUsuarioCreacion)
    VALUES (_dsUsuario, UNHEX(_dsPassword), '1', _dsUsuarioCreacion);

    UPDATE usuarios
    SET dsId = LPAD(LAST_INSERT_ID(), 3, '0')
    WHERE id = LAST_INSERT_ID();
END$$
DELIMITER ;


-- usuario de conexion con privilegios minimos (solo ejecutar los dos procedimientos)
CREATE USER IF NOT EXISTS 'usr_login'@'localhost' IDENTIFIED BY 'Login2026*';
GRANT EXECUTE ON PROCEDURE db_sistema_login.sp_ObtenerUsuario TO 'usr_login'@'localhost';
GRANT EXECUTE ON PROCEDURE db_sistema_login.sp_RegistrarUsuario TO 'usr_login'@'localhost';
FLUSH PRIVILEGES;


-- pruebas
CALL sp_ObtenerUsuario('admin');
SHOW GRANTS FOR 'usr_login'@'localhost';
