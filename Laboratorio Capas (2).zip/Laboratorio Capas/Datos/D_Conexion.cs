namespace Datos
{
    public class D_Conexion
    {
        // usuario con permiso solo para ejecutar los procedimientos
        public static string cadenaConexion = "Server=localhost; Database=db_sistema_login; Uid=usr_login; Pwd=Login2026*;";
    }
}
