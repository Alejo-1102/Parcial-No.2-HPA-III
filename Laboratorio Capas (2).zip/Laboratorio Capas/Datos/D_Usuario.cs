using System.Data;
using MySql.Data.MySqlClient;
using Entidades;

namespace Datos
{
    public class D_Usuario : D_Conexion
    {
        public static E_Usuario? ObtenerPorUsuario(string strUsuario)
        {
            using (MySqlConnection conexion = new MySqlConnection(cadenaConexion))
            {
                conexion.Open();
                using (MySqlCommand cmd = new MySqlCommand("sp_ObtenerUsuario", conexion))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("_dsUsuario", strUsuario);

                    using (MySqlDataReader fReader = cmd.ExecuteReader())
                    {
                        if (!fReader.Read())
                        {
                            return null;
                        }

                        E_Usuario usuario = new E_Usuario();
                        usuario.id = fReader.GetInt32("id");
                        usuario.dsUsuario = fReader.GetString("dsUsuario");
                        usuario.dsPassword = fReader.GetString("dsPassword");
                        return usuario;
                    }
                }
            }
        }

        public static bool Registrar(E_Usuario usuario)
        {
            try
            {
                using (MySqlConnection conexion = new MySqlConnection(cadenaConexion))
                {
                    conexion.Open();
                    using (MySqlCommand cmd = new MySqlCommand("sp_RegistrarUsuario", conexion))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("_dsUsuario", usuario.dsUsuario);
                        cmd.Parameters.AddWithValue("_dsPassword", usuario.dsPassword);
                        cmd.Parameters.AddWithValue("_dsUsuarioCreacion", usuario.dsUsuarioCreacion);
                        cmd.ExecuteNonQuery();
                        return true;
                    }
                }
            }
            catch (MySqlException ex) when (ex.Number == 1062)
            {
                // usuario duplicado
                return false;
            }
        }
    }
}
