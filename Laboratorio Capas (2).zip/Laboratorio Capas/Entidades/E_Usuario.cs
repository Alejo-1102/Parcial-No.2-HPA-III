namespace Entidades
{
    public class E_Usuario
    {
        public int id { get; set; }
        public string dsId { get; set; } = string.Empty;
        public string dsUsuario { get; set; } = string.Empty;
        public string dsPassword { get; set; } = string.Empty;
        public char dsEstado { get; set; }
        public string dsUsuarioCreacion { get; set; } = string.Empty;
        public DateTime dtFechaCreacion { get; set; }
        public string idUsuarioModificacion { get; set; } = string.Empty;
        public DateTime dtFechaModificacion { get; set; }
    }
}
