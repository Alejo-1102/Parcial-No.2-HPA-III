using System.Security.Cryptography;
using System.Text;

namespace Negocio
{
    public class HashService : IHashService
    {
        public string GenerarHash(string textoPlano)
        {
            byte[] bytes = SHA512.HashData(Encoding.UTF8.GetBytes(textoPlano));
            return Convert.ToHexString(bytes).ToLower();
        }
    }
}
