namespace Negocio
{
    // contrato 1: generar el hash
    public interface IHashService
    {
        string GenerarHash(string textoPlano);
    }
}
