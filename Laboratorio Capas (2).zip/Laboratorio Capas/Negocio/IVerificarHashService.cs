namespace Negocio
{
    // contrato 2: verificar el hash
    public interface IVerificarHashService
    {
        bool Verificar(string textoPlano, string hashAlmacenado);
    }
}
