using Entidades;
using Datos;

namespace Negocio
{
    public class N_Usuario
    {
        private readonly IHashService hashService;
        private readonly IVerificarHashService verificarService;

        public N_Usuario()
        {
            hashService = new HashService();
            verificarService = new VerificarHashService(hashService);
        }

        public N_Usuario(IHashService hashService, IVerificarHashService verificarService)
        {
            this.hashService = hashService;
            this.verificarService = verificarService;
        }

        public E_Usuario? Login(string strUsuario, string strPassword)
        {
            E_Usuario? usuario = D_Usuario.ObtenerPorUsuario(strUsuario);

            if (usuario == null)
            {
                return null;
            }

            if (!verificarService.Verificar(strPassword, usuario.dsPassword))
            {
                return null;
            }

            usuario.dsPassword = string.Empty;
            return usuario;
        }

        public bool Registrar(string strUsuario, string strPassword, string strCreador)
        {
            E_Usuario usuario = new E_Usuario();
            usuario.dsUsuario = strUsuario;
            usuario.dsPassword = hashService.GenerarHash(strPassword);
            usuario.dsUsuarioCreacion = strCreador;
            return D_Usuario.Registrar(usuario);
        }
    }
}
