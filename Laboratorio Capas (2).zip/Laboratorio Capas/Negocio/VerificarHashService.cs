namespace Negocio
{
    public class VerificarHashService : IVerificarHashService
    {
        private readonly IHashService hashService;

        public VerificarHashService(IHashService hashService)
        {
            this.hashService = hashService;
        }

        public bool Verificar(string textoPlano, string hashAlmacenado)
        {
            string hashNuevo = hashService.GenerarHash(textoPlano);
            return hashNuevo == hashAlmacenado.ToLower();
        }
    }
}
