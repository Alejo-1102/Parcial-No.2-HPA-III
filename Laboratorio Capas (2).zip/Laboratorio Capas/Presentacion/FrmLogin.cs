using Entidades;

namespace Presentacion
{
    public partial class FrmLogin : Form, IVistaLogin
    {
        private readonly LoginPresentador presentador;

        public E_Usuario UsuarioActual { get; private set; } = new E_Usuario();

        public string Usuario => txtUsuario.Text;
        public string Password => txtPassword.Text;

        public FrmLogin()
        {
            InitializeComponent();
            presentador = new LoginPresentador(this);
        }

        public void MostrarError(string mensaje)
        {
            MessageBox.Show(mensaje, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtPassword.Clear();
            txtPassword.Focus();
        }

        public void LoginCorrecto(E_Usuario usuario)
        {
            UsuarioActual = usuario;
            DialogResult = DialogResult.OK;
        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            presentador.Ingresar();
        }
    }
}
