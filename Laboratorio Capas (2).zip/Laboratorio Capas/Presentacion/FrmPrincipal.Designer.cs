namespace Presentacion
{
    partial class FrmPrincipal
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            pnlMenu = new Panel();
            lblTitulo = new Label();
            lblHora = new Label();
            lblFecha = new Label();
            btnRegistrar = new Button();
            btnSalir = new Button();
            lblSesion = new Label();
            tmrHora = new System.Windows.Forms.Timer(components);
            pnlMenu.SuspendLayout();
            SuspendLayout();
            //
            // pnlMenu
            //
            pnlMenu.BackColor = Color.FromArgb(0, 102, 204);
            pnlMenu.Controls.Add(lblTitulo);
            pnlMenu.Controls.Add(lblHora);
            pnlMenu.Controls.Add(lblFecha);
            pnlMenu.Controls.Add(btnRegistrar);
            pnlMenu.Controls.Add(btnSalir);
            pnlMenu.Controls.Add(lblSesion);
            pnlMenu.Dock = DockStyle.Left;
            pnlMenu.Name = "pnlMenu";
            pnlMenu.Size = new Size(200, 561);
            //
            // lblTitulo
            //
            lblTitulo.AutoSize = true;
            lblTitulo.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            lblTitulo.ForeColor = Color.White;
            lblTitulo.Location = new Point(15, 20);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Text = "Sistema";
            //
            // lblHora
            //
            lblHora.AutoSize = true;
            lblHora.Font = new Font("Segoe UI", 20F);
            lblHora.ForeColor = Color.White;
            lblHora.Location = new Point(12, 65);
            lblHora.Name = "lblHora";
            lblHora.Text = "00:00:00";
            //
            // lblFecha
            //
            lblFecha.AutoSize = true;
            lblFecha.ForeColor = Color.White;
            lblFecha.Location = new Point(16, 110);
            lblFecha.Name = "lblFecha";
            lblFecha.Text = "00/00/0000";
            //
            // btnRegistrar
            //
            btnRegistrar.FlatAppearance.BorderSize = 0;
            btnRegistrar.FlatStyle = FlatStyle.Flat;
            btnRegistrar.ForeColor = Color.White;
            btnRegistrar.Location = new Point(0, 170);
            btnRegistrar.Name = "btnRegistrar";
            btnRegistrar.Padding = new Padding(15, 0, 0, 0);
            btnRegistrar.Size = new Size(200, 45);
            btnRegistrar.Text = "Registrar usuario";
            btnRegistrar.TextAlign = ContentAlignment.MiddleLeft;
            btnRegistrar.UseVisualStyleBackColor = true;
            btnRegistrar.Click += btnRegistrar_Click;
            //
            // btnSalir
            //
            btnSalir.FlatAppearance.BorderSize = 0;
            btnSalir.FlatStyle = FlatStyle.Flat;
            btnSalir.ForeColor = Color.White;
            btnSalir.Location = new Point(0, 215);
            btnSalir.Name = "btnSalir";
            btnSalir.Padding = new Padding(15, 0, 0, 0);
            btnSalir.Size = new Size(200, 45);
            btnSalir.Text = "Salir";
            btnSalir.TextAlign = ContentAlignment.MiddleLeft;
            btnSalir.UseVisualStyleBackColor = true;
            btnSalir.Click += btnSalir_Click;
            //
            // lblSesion
            //
            lblSesion.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            lblSesion.AutoSize = true;
            lblSesion.ForeColor = Color.White;
            lblSesion.Location = new Point(16, 505);
            lblSesion.Name = "lblSesion";
            lblSesion.Text = "Sesión iniciada:";
            //
            // tmrHora
            //
            tmrHora.Interval = 1000;
            tmrHora.Tick += tmrHora_Tick;
            //
            // FrmPrincipal
            //
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(960, 561);
            Controls.Add(pnlMenu);
            IsMdiContainer = true;
            Name = "FrmPrincipal";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Sistema";
            Load += FrmPrincipal_Load;
            pnlMenu.ResumeLayout(false);
            pnlMenu.PerformLayout();
            ResumeLayout(false);
        }

        private Panel pnlMenu;
        private Label lblTitulo;
        private Label lblHora;
        private Label lblFecha;
        private Button btnRegistrar;
        private Button btnSalir;
        private Label lblSesion;
        private System.Windows.Forms.Timer tmrHora;
    }
}
