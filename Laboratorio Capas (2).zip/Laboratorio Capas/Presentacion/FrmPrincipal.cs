using Entidades;

namespace Presentacion
{
    public partial class FrmPrincipal : Form, IVistaPrincipal
    {
        private readonly PrincipalPresentador presentador;
        private readonly E_Usuario usuario;

        public FrmPrincipal(E_Usuario usuario)
        {
            InitializeComponent();
            this.usuario = usuario;
            presentador = new PrincipalPresentador(this, usuario);
        }

        public void MostrarSesion(string texto)
        {
            lblSesion.Text = texto;
        }

        public void MostrarHora(string hora, string fecha)
        {
            lblHora.Text = hora;
            lblFecha.Text = fecha;
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            presentador.Iniciar();
            tmrHora.Start();
        }

        private void tmrHora_Tick(object sender, EventArgs e)
        {
            presentador.ActualizarHora();
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            foreach (Form hijo in MdiChildren)
            {
                if (hijo is FrmRegistro)
                {
                    hijo.Activate();
                    return;
                }
            }

            FrmRegistro registro = new FrmRegistro(usuario.dsUsuario);
            registro.MdiParent = this;
            registro.Show();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
