namespace Presentacion
{
    partial class FrmRegistro
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblUsuario = new Label();
            txtUsuario = new TextBox();
            lblPassword = new Label();
            txtPassword = new TextBox();
            lblConfirmar = new Label();
            txtConfirmar = new TextBox();
            btnRegistrar = new Button();
            SuspendLayout();
            //
            // lblUsuario
            //
            lblUsuario.AutoSize = true;
            lblUsuario.Location = new Point(40, 25);
            lblUsuario.Name = "lblUsuario";
            lblUsuario.Text = "Usuario";
            //
            // txtUsuario
            //
            txtUsuario.Location = new Point(40, 45);
            txtUsuario.MaxLength = 50;
            txtUsuario.Name = "txtUsuario";
            txtUsuario.Size = new Size(220, 23);
            txtUsuario.TabIndex = 0;
            //
            // lblPassword
            //
            lblPassword.AutoSize = true;
            lblPassword.Location = new Point(40, 85);
            lblPassword.Name = "lblPassword";
            lblPassword.Text = "Contraseña";
            //
            // txtPassword
            //
            txtPassword.Location = new Point(40, 105);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(220, 23);
            txtPassword.TabIndex = 1;
            txtPassword.UseSystemPasswordChar = true;
            //
            // lblConfirmar
            //
            lblConfirmar.AutoSize = true;
            lblConfirmar.Location = new Point(40, 145);
            lblConfirmar.Name = "lblConfirmar";
            lblConfirmar.Text = "Confirmar contraseña";
            //
            // txtConfirmar
            //
            txtConfirmar.Location = new Point(40, 165);
            txtConfirmar.Name = "txtConfirmar";
            txtConfirmar.Size = new Size(220, 23);
            txtConfirmar.TabIndex = 2;
            txtConfirmar.UseSystemPasswordChar = true;
            //
            // btnRegistrar
            //
            btnRegistrar.Location = new Point(40, 210);
            btnRegistrar.Name = "btnRegistrar";
            btnRegistrar.Size = new Size(220, 32);
            btnRegistrar.TabIndex = 3;
            btnRegistrar.Text = "Registrar";
            btnRegistrar.UseVisualStyleBackColor = true;
            btnRegistrar.Click += btnRegistrar_Click;
            //
            // FrmRegistro
            //
            AcceptButton = btnRegistrar;
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(300, 270);
            Controls.Add(lblUsuario);
            Controls.Add(txtUsuario);
            Controls.Add(lblPassword);
            Controls.Add(txtPassword);
            Controls.Add(lblConfirmar);
            Controls.Add(txtConfirmar);
            Controls.Add(btnRegistrar);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "FrmRegistro";
            Text = "Registrar usuario";
            ResumeLayout(false);
            PerformLayout();
        }

        private Label lblUsuario;
        private TextBox txtUsuario;
        private Label lblPassword;
        private TextBox txtPassword;
        private Label lblConfirmar;
        private TextBox txtConfirmar;
        private Button btnRegistrar;
    }
}
