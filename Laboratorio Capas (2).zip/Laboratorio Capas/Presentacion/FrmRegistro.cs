namespace Presentacion
{
    public partial class FrmRegistro : Form, IVistaRegistro
    {
        private readonly RegistroPresentador presentador;

        public string Usuario => txtUsuario.Text;
        public string Password => txtPassword.Text;
        public string Confirmacion => txtConfirmar.Text;

        public FrmRegistro(string creador)
        {
            InitializeComponent();
            presentador = new RegistroPresentador(this, creador);
        }

        public void MostrarMensaje(string mensaje)
        {
            MessageBox.Show(mensaje, "Registro de usuarios", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public void LimpiarCampos()
        {
            txtUsuario.Clear();
            txtPassword.Clear();
            txtConfirmar.Clear();
            txtUsuario.Focus();
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            presentador.Registrar();
        }
    }
}
