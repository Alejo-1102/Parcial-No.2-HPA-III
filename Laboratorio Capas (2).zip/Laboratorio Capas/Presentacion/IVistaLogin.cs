using Entidades;

namespace Presentacion
{
    public interface IVistaLogin
    {
        string Usuario { get; }
        string Password { get; }
        void MostrarError(string mensaje);
        void LoginCorrecto(E_Usuario usuario);
    }
}
