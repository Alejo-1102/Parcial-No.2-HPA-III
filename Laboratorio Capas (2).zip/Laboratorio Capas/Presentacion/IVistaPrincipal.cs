namespace Presentacion
{
    public interface IVistaPrincipal
    {
        void MostrarSesion(string texto);
        void MostrarHora(string hora, string fecha);
    }
}
