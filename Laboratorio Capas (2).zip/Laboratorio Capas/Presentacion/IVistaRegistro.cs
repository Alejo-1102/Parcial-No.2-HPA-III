namespace Presentacion
{
    public interface IVistaRegistro
    {
        string Usuario { get; }
        string Password { get; }
        string Confirmacion { get; }
        void MostrarMensaje(string mensaje);
        void LimpiarCampos();
    }
}
