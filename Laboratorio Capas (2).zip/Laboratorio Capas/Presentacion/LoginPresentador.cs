using Entidades;
using Negocio;

namespace Presentacion
{
    public class LoginPresentador
    {
        private readonly IVistaLogin vista;
        private readonly N_Usuario negocio = new N_Usuario();

        public LoginPresentador(IVistaLogin vista)
        {
            this.vista = vista;
        }

        public void Ingresar()
        {
            if (string.IsNullOrWhiteSpace(vista.Usuario) || string.IsNullOrWhiteSpace(vista.Password))
            {
                vista.MostrarError("Ingrese usuario y contraseña");
                return;
            }

            try
            {
                E_Usuario? usuario = negocio.Login(vista.Usuario.Trim(), vista.Password);

                if (usuario == null)
                {
                    vista.MostrarError("Usuario o contraseña incorrectos");
                    return;
                }

                vista.LoginCorrecto(usuario);
            }
            catch (Exception)
            {
                vista.MostrarError("No se pudo conectar con la base de datos");
            }
        }
    }
}
