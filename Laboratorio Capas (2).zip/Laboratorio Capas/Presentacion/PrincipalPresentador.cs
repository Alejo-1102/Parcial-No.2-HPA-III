using Entidades;

namespace Presentacion
{
    public class PrincipalPresentador
    {
        private readonly IVistaPrincipal vista;
        private readonly E_Usuario usuario;

        public PrincipalPresentador(IVistaPrincipal vista, E_Usuario usuario)
        {
            this.vista = vista;
            this.usuario = usuario;
        }

        public void Iniciar()
        {
            vista.MostrarSesion("Sesión iniciada:\n" + usuario.dsUsuario);
            ActualizarHora();
        }

        public void ActualizarHora()
        {
            DateTime ahora = DateTime.Now;
            vista.MostrarHora(ahora.ToString("HH:mm:ss"), ahora.ToString("dd/MM/yyyy"));
        }
    }
}
