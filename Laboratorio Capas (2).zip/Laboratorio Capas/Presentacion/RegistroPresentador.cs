using Negocio;

namespace Presentacion
{
    public class RegistroPresentador
    {
        private readonly IVistaRegistro vista;
        private readonly N_Usuario negocio = new N_Usuario();
        private readonly string creador;

        public RegistroPresentador(IVistaRegistro vista, string creador)
        {
            this.vista = vista;
            this.creador = creador;
        }

        public void Registrar()
        {
            if (string.IsNullOrWhiteSpace(vista.Usuario) || string.IsNullOrWhiteSpace(vista.Password))
            {
                vista.MostrarMensaje("Complete todos los campos");
                return;
            }

            if (vista.Password.Length < 6)
            {
                vista.MostrarMensaje("La contraseña debe tener al menos 6 caracteres");
                return;
            }

            if (vista.Password != vista.Confirmacion)
            {
                vista.MostrarMensaje("Las contraseñas no coinciden");
                return;
            }

            try
            {
                bool creado = negocio.Registrar(vista.Usuario.Trim(), vista.Password, creador);

                if (creado)
                {
                    vista.MostrarMensaje("Usuario registrado correctamente");
                    vista.LimpiarCampos();
                }
                else
                {
                    vista.MostrarMensaje("Ese usuario ya existe");
                }
            }
            catch (Exception)
            {
                vista.MostrarMensaje("No se pudo conectar con la base de datos");
            }
        }
    }
}
